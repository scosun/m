// document.write("<link rel='stylesheet' href='/m/css/scosun.css' media='all'>");
document.write("<title>龙居里® Meeting++</title>");
document.write("<link rel='icon' type='image/png' sizes='16x16' href='images/favicon.ico'>");